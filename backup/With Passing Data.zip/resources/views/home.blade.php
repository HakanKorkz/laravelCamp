@extends("app")
@section("tittle")
Ana Sayfa
@endsection

@section("content")
İlk sayfa bu
@endsection
