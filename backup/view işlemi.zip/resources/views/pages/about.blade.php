@extends("app")
@section("tittle")
    About
@endsection
@section("content")
    About Blade Pages
@endsection
