<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel | <?php echo $__env->yieldContent("tittle"); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <?php echo $__env->yieldContent("style"); ?>
</head>
<body>
<?php echo $__env->yieldContent("content"); ?>

<?php echo $__env->yieldContent("script"); ?>
</body>
</html>
<?php /**PATH C:\yazilim\wamp64\www\laravelCamp\resources\views/layouts/app.blade.php ENDPATH**/ ?>