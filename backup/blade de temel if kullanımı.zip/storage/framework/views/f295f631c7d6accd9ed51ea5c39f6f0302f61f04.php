<?php $__env->startSection("tittle"); ?>
    Hakkımızda
<?php $__env->stopSection(); ?>
<?php $__env->startSection("style"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
        <h1>
            Hakkımda!
        </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\yazilim\wamp64\www\laravelCamp\resources\views/about.blade.php ENDPATH**/ ?>