<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<?php
    $number=2
?>

<?php if($number ===1): ?>
    Sayı: <?php echo e($number); ?> istenilendir
<?php else: ?>
    Sayı: <?php echo e($number); ?> istenilen değildir

<?php endif; ?>
</body>
</html>
<?php /**PATH C:\yazilim\wamp64\www\laravelCamp\resources\views/home.blade.php ENDPATH**/ ?>