<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<?php
    $users=["Hakan","Tuna","Rıdvan","Aysun"]
?>

<?php if(count($users)): ?>
    <hr>
    <h1>Foreach döngüsü</h1>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <?php echo e($user); ?>

        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <hr>

    <hr>
    <h1>For döngüsü</h1>

    <?php for($i=0; $i < count($users); $i++): ?>
        <li>
            <?php echo e($users[$i]); ?>

        </li>
    <?php endfor; ?>
    <hr>
<?php endif; ?>
</body>
</html>
<?php /**PATH C:\yazilim\wamp64\www\laravelCamp\resources\views/home.blade.php ENDPATH**/ ?>