<?php $__env->startSection("tittle"); ?>
    About
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    About Blade Pages
<?php $__env->stopSection(); ?>

<?php echo $__env->make("app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\yazilim\wamp64\www\laravelCamp\resources\views/pages/about.blade.php ENDPATH**/ ?>