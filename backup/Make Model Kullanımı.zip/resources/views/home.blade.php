@extends("app")
@section("tittle")
Ana Sayfa
@endsection

@section("content")

{{--
    php artisan make:model oluştururken dikkat etmemiz gereken nokta kural model Pascal case yazılır tablo adı olarak yazılmalıdır
    php artisan make:model Adi -m  diyerek hem o modeli ve migration oluşturulur
  --}}


@endsection
