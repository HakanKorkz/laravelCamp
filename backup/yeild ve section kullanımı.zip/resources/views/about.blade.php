@extends("layouts.app")
@section("tittle")
    Hakkımızda
@endsection
@section("style")

@endsection

@section("content")
        <h1>
            Hakkımda!
        </h1>
@endsection

@section("script")


@endsection
