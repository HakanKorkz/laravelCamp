@extends("layouts.app")
@section("tittle")
    Home
@endsection
@section("style")
    <link rel="stylesheet" href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css"/>

@endsection

@section("content")
    <main class="w-full fle">
        <h1 class="text-3xl font-bold underline bg-red-300">
            Hello world!
        </h1>
        <h1 class="text-3xl font-bold underline bg-red-300">
            Hello world!
        </h1>
    </main>
@endsection
{{--Section lar ile yield ile rezerve edilen alanların verilerini dolduruyoruz gerekli işlemler vs edilerek yield adlandırmaların da css gibi özel ifadeye kaçacak değerlerden kaçınıyoruz--}}

@section("script")


@endsection
