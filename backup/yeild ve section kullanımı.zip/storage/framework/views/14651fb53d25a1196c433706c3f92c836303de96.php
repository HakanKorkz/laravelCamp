<?php $__env->startSection("tittle"); ?>
    Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <main class="w-full fle">
        <h1 class="text-3xl font-bold underline bg-red-300">
        Hello world!
        </h1>
        <h1 class="text-3xl font-bold underline bg-red-300">
        Hello world!
        </h1>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("script"); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\yazilim\wamp64\www\laravelCamp\resources\views/home.blade.php ENDPATH**/ ?>