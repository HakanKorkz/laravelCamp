<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<?php
    $data=2;
?>

<?php switch($data):
    case (1): ?>
        Data değerin 1'e eşittir
        <?php break; ?>

    <?php case (2): ?>
        Data değerin 2'e eşittir
        <?php break; ?>
    <?php default: ?>
    Data değerin: <?php echo e($data); ?>

<?php endswitch; ?>
</body>
</html>
<?php /**PATH C:\yazilim\wamp64\www\laravelCamp\resources\views/home.blade.php ENDPATH**/ ?>