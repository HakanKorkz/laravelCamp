@extends("app")
@section("tittle")
Ana Sayfa
@endsection

@section("content")

{{--
  php artisan migrate veri tabanı tablolarını oluşturur
  php artisan migrate:fresh veri tabanı tablolarını silip tekrar  oluşturur not önemli veriler varsa gidecektir
  php artisan make:migration create_orders_table  ile yeni bir tablo oluşturulur create_tabloadi_table olarak tanımlanır
  --}}


@endsection
