@extends("app")
@section("tittle")
    Hakkımızda
@endsection

@section("content")
    Hakkımızda sayfası
@endsection
