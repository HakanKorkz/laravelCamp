<?php $__env->startSection("tittle"); ?>
Ana Sayfa
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>




<?php $__env->stopSection(); ?>

<?php echo $__env->make("app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\yazilim\wamp64\www\laravelCamp\resources\views/home.blade.php ENDPATH**/ ?>