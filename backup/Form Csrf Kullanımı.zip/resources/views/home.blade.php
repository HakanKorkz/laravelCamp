@extends("app")
@section("tittle")
Ana Sayfa
@endsection

@section("content")

    <form action="">
        @csrf
        <input type="text" name="name" aria-label="">
        <input type="submit" value="submit">
    </form>


@endsection
